<template>
  <div id="extension-page">
    Example extension page
  </div>
</template>

<script>
export default {
  name: 'ExtensionPage'
}
</script>

<style scoped>
  /* Always export scoped styles to not break the app */
  #extension-page {
    color: blue;
  }
</style>
