import { ExampleState } from '../types/ExampleState'

export const state: ExampleState = {
  users: null
}