---
name: Feature request
about: Suggest an idea for this project

---

## What is the motivation for adding / enhancing this feature?
<!-- Describe the motivation or the concrete use case for new feature or why one of current ones should be enhanced. -->


## What are the acceptance criteria 
<!-- List the acceptance criteria for this task in a form of a list. -->
- ...
- ...

# Can you complete this feature request by yourself?
<!-- 
If you can handle the development of this feature request and later propose a Pull Request with the solution please answer YES. otherwise answer NO.
-->

## Additional information
<!-- If you think that any additional information would be useful please provide them here. -->
