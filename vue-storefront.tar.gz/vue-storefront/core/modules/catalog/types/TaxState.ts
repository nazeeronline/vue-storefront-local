export default interface TaxState {
  rules: any[]
}
