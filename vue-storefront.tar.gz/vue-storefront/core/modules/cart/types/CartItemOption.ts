export default interface CartItemOption {
    label: string,
    value: string
}
