import { Register } from '@vue-storefront/core/modules/user/components/Register'
export default {
  mixins: [Register]
}
