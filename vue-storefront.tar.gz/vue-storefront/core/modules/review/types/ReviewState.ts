export default interface ReviewState {
  items: any[]
}
