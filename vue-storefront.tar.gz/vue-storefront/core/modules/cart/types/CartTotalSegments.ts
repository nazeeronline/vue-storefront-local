import CartTotalSegmentsItem from './CartTotalSegmentsItem'
export default interface CartTotalSegments extends Array<CartTotalSegmentsItem>{}
