---
home: true
heroImage: /logo.png
actionText: Get Started →
actionLink: /guide/
---
