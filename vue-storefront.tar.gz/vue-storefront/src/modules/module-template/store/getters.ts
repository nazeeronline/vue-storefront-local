import { ExampleState } from '../types/ExampleState'
import { GetterTree } from 'vuex';

export const getters: GetterTree<ExampleState, any> = {}