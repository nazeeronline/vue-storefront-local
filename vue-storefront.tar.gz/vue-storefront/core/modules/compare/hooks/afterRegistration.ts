export function afterRegistration({ Vue, config, store, isServer }){
}